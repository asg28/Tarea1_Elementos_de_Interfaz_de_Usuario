package com.example.uielementsdemo.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uielementsdemo.adapters.SimpleAdapter
import com.example.uielementsdemo.data.SampleItem
import com.example.uielementsdemo.databinding.FragmentListBinding

class ListFragment : Fragment() {
    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.title.text = "\n\nListas (RecyclerView)"
        binding.description.text = "Muestran colecciones largas de elementos de manera eficiente."

        val data = (1..30).map { SampleItem("Elemento $it", "Subtítulo de ejemplo $it") }
        val adapter = SimpleAdapter(data)
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
