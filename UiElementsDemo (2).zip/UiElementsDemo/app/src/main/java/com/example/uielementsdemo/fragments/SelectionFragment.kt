package com.example.uielementsdemo.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.uielementsdemo.databinding.FragmentSelectionBinding

class SelectionFragment : Fragment() {
    private var _binding: FragmentSelectionBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSelectionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.title.text = "\n\nElementos de selección"
        binding.description.text = "Sirven para elegir opciones, activar/desactivar o seleccionar una entre varias."

        binding.checkBox.setOnCheckedChangeListener { _, isChecked ->
            binding.result.text = if (isChecked) "CheckBox: activado" else "CheckBox: desactivado"
        }
        binding.radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val text = when (checkedId) {
                binding.radio1.id -> "Radio: Opción 1"
                binding.radio2.id -> "Radio: Opción 2"
                else -> "Radio: ninguna"
            }
            binding.result.text = text
        }
        binding.switch1.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(requireContext(), "Switch: ${if (isChecked) "Activado" else "Desactivado"}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
