package com.example.uielementsdemo.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.uielementsdemo.databinding.FragmentTextfieldsBinding

class TextFieldsFragment : Fragment() {
    private var _binding: FragmentTextfieldsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTextfieldsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.title.text = "\n\nEditText (Campos de texto)\n"
        binding.description.text = "Permiten capturar texto del usuario, como nombres o contraseñas."

        binding.editNormal.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                binding.mirror.text = "Escribiste: ${s.toString()}"
            }
        })

        binding.btnEnviar.setOnClickListener {
            Toast.makeText(requireContext(), "Enviado: ${binding.editNormal.text}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
