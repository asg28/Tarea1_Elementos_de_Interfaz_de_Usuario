package com.example.uielementsdemo.data

data class SampleItem(
    val title: String,
    val subtitle: String
)
