package com.example.uielementsdemo.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.uielementsdemo.databinding.FragmentInfoBinding

class InfoFragment : Fragment() {
    private var _binding: FragmentInfoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.title.text = "\n\nInformación (TextView, ImageView, ProgressBar)"
        binding.description.text = "Muestran contenido al usuario, como texto, imágenes o estados de carga.\n"
        binding.description.text = "Al hacer clic en el icono se muestra y desaparece el estado de carga."

        // Simple demo: toggle progress bar when image is tapped
        binding.image.setOnClickListener {
            binding.progress.isVisible = !binding.progress.isVisible
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
