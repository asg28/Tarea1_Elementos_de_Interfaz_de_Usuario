package com.example.uielementsdemo.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.uielementsdemo.data.SampleItem
import com.example.uielementsdemo.databinding.ItemSampleBinding

class SimpleAdapter(
    private val items: List<SampleItem>
) : RecyclerView.Adapter<SimpleAdapter.VH>() {

    inner class VH(val binding: ItemSampleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemSampleBinding.inflate(inflater, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.title.text = item.title
        holder.binding.subtitle.text = item.subtitle
        holder.binding.root.setOnClickListener {
            Toast.makeText(holder.binding.root.context, "Click: ${item.title}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int = items.size
}
