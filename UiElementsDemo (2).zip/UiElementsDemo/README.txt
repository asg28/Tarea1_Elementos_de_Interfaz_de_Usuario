UI Elements Demo (Android, Kotlin)
==================================

Descripción
-----------
App de ejemplo con **1 Activity** y **5 Fragments** para demostrar elementos comunes de UI:
- TextFields (EditText)
- Botones (Button, ImageButton, FloatingActionButton)
- Elementos de selección (CheckBox, RadioButton, Switch)
- Listas (RecyclerView)
- Elementos de información (TextView, ImageView, ProgressBar)

Navegación
----------
Usa **BottomNavigationView** con Navigation Component para cambiar de fragment.
Además, el FAB del fragment de Botones navega hacia el fragment de Lista como ejemplo de flujo entre fragments.

Requisitos
----------
- Android Studio Giraffe/Koala o superior
- Kotlin 1.9.x
- compileSdk = 34, minSdk = 24

Cómo ejecutar
-------------
1. Abre Android Studio > *Open* > selecciona la carpeta `UiElementsDemo`.
2. Sincroniza Gradle si te lo pide.
3. Ejecuta en un emulador o dispositivo físico.

Toma de Screenshots
-------------------
En Android Studio, usa *Logcat* o el emulador para capturas:
- Muestra cada fragment y toma una captura.
- Guarda como `screenshots/1_textfields.png`, ..., `5_info.png`.

Estructura
----------
- MainActivity + BottomNavigation
- 5 Fragments en `com.example.uielementsdemo.fragments`
- Adapter para RecyclerView en `adapters/SimpleAdapter.kt`
- Layouts en `res/layout`

Créditos
--------
Creado como demo educativa. Texto y UI en español.
